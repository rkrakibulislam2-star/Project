import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Testimonial } from '../types';

export default function Testimonials() {
  const reviews: Testimonial[] = [
    {
      id: 'r-1',
      name: 'Abdullah Al Mahmud',
      role: 'Mirpur Resident & Fitness Enthusiast',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/651944785_18032074997789736_8717457551348290165_n_n9rqkh',
      review: 'POWERSURGE has completely rebuilt my workout schedule. The duplex design is superb: cardiovascular floors are completely separate from strength weight fields, meaning there’s never any rush. The AC and steam bath facilities are always absolutely pristine.',
      rating: 5,
    },
    {
      id: 'r-2',
      name: 'Raihan Ahmed',
      role: 'Local Powerlifter',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/images_1_qzzcuj',
      review: "Best duplex gym in Dhaka, hands down! Having a dedicated women’s common area, secure bicycle parking, and professional national coaches makes the atmosphere extremely empowering and friendly. Rony Raj and the team inspire daily consistency.",
      rating: 5,
    },
    {
      id: 'r-3',
      name: 'Redwan Ahmed',
      role: 'Tech Consultant & Member since 2024',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/images_xg0hpg',
      review: 'The futuristic luxury atmosphere makes every workout feel premium. Unbelievable value: the high-contrast lighting, locker security, and the incredible promotional packages are unparalleled. I highly recommend POWERSURGE.',
      rating: 5,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  return (
    <section id="testimonials" className="py-24 bg-cyber-dark relative overflow-hidden select-none">
      {/* Cinematic Studio Lighting: Left and Right Corner Spotlight Beams */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div 
          className="absolute top-0 left-0 w-[45%] h-[90vh] bg-gradient-to-br from-cyber-red/[0.035] via-transparent to-transparent opacity-85"
          style={{
            clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%, 0% 100%)',
            filter: 'blur(40px)'
          }}
        />
        <div 
          className="absolute top-0 right-0 w-[45%] h-[90vh] bg-gradient-to-bl from-cyber-red/[0.035] via-transparent to-transparent opacity-85"
          style={{
            clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 50% 100%)',
            filter: 'blur(40px)'
          }}
        />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[70%] rounded-full bg-cyber-red/[0.012] blur-[150px]" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <span className="font-mono text-xs tracking-[0.3em] font-semibold text-cyber-red uppercase block">
            MEMBER DIRECTIVE
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white uppercase italic">
            STORIES OF <span className="text-cyber-red text-glow-red">THE SURGERS</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto font-light font-sans">
            Hear straight from our active members who transformed their energy levels inside our premium fitness facility.
          </p>
        </div>

        {/* Dynamic Carousel / Slider (Active item display with elegant glass design) */}
        <div className="max-w-3xl mx-auto relative px-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, scale: 0.97, x: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.97, x: -20 }}
              transition={{ duration: 0.4, ease: 'easeInOut' }}
              className="glass-card bg-[#0a0a0d]/80 border border-cyber-red/20 rounded-3xl p-8 sm:p-12 shadow-[0_15px_40px_rgba(0,0,0,0.8)] backdrop-blur-md relative overflow-hidden"
            >
              {/* Giant abstract Red quote icon background decoration */}
              <div className="absolute -top-6 -right-6 text-cyber-red/5 scale-150 pointer-events-none select-none">
                <Quote className="w-48 h-48 stroke-[1.2]" />
              </div>

              {/* Layout Content */}
              <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8 relative z-10">
                {/* Profile Image with subtle framing ring */}
                <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full p-[2px] bg-cyber-dark/80 border border-cyber-red/40 overflow-hidden flex-shrink-0">
                  <img
                    src={reviews[currentIndex].image}
                    alt={reviews[currentIndex].name}
                    className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Review Context */}
                <div className="space-y-4 flex-grow text-center sm:text-left">
                  {/* Rating Stars */}
                  <div className="flex justify-center sm:justify-start items-center gap-1">
                    {[...Array(reviews[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-cyber-red fill-cyber-red drop-shadow-[0_0_4px_rgba(255,18,29,0.4)]" />
                    ))}
                  </div>

                  {/* Body Statement */}
                  <p className="text-zinc-300 font-sans text-sm sm:text-base leading-relaxed font-light italic">
                    "{reviews[currentIndex].review}"
                  </p>

                  {/* Poster details */}
                  <div>
                    <h4 className="font-display font-extrabold text-white text-lg tracking-normal uppercase italic">
                      {reviews[currentIndex].name}
                    </h4>
                    <p className="font-mono text-[10px] tracking-widest text-cyber-red uppercase mt-0.5">
                      {reviews[currentIndex].role}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Slider controls on the sides */}
          <div className="absolute top-1/2 -translate-y-1/2 -left-4 sm:-left-16 z-20">
            <motion.button
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.9 }}
              onClick={handlePrev}
              className="w-11 h-11 rounded-full border border-white/10 hover:border-cyber-red/50 text-zinc-400 hover:text-white bg-[#0e0e11]/90 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-lg"
              aria-label="Previous Review"
            >
              <ChevronLeft className="w-5 h-5" />
            </motion.button>
          </div>
          
          <div className="absolute top-1/2 -translate-y-1/2 -right-4 sm:-right-16 z-20">
            <motion.button
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleNext}
              className="w-11 h-11 rounded-full border border-white/10 hover:border-cyber-red/50 text-zinc-400 hover:text-white bg-[#0e0e11]/90 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-lg"
              aria-label="Next Review"
            >
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </div>
        </div>

        {/* Dynamic Carousel dots locator */}
        <div className="flex justify-center items-center gap-2 mt-8">
          {reviews.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                i === currentIndex ? 'w-6 bg-cyber-red shadow-[0_0_8px_#ff121d]' : 'w-2 bg-zinc-800 hover:bg-zinc-700'
              }`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}

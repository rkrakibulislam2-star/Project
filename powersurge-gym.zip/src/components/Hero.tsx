import { motion } from 'motion/react';
import { Shield, Sparkles, Flame, Play, ArrowRight } from 'lucide-react';

interface HeroProps {
  onJoinClick: () => void;
  onViewPlansClick: () => void;
}

export default function Hero({ onJoinClick, onViewPlansClick }: HeroProps) {
  const heroImageSrc = 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto,q_auto,w_1600/02a83aa76a5746e7b16951b002950a59_1_2_nku3v1';

  return (
    <section
      id="home"
      className="relative min-h-screen bg-cyber-dark overflow-hidden flex flex-col justify-center z-10 pt-28 sm:pt-32 lg:pt-36 pb-12 sm:pb-16 lg:pb-20"
    >
      {/* 
        CINEMATIC FULL-SCREEN BACKGROUND:
        - Covers 100% width and height.
        - The real image remains perfectly clear and sharp on the right side.
        - A smooth gradual gradient overlay on the left fades it into deep dark charcoal to ensure pristine text readability.
      */}
      <div className="absolute inset-0 z-0 select-none pointer-events-none">
        <img
          src={heroImageSrc}
          onError={(e) => {
            e.currentTarget.src = '/src/assets/images/gym_neon_interior_1779389124745.png';
          }}
          alt="POWERSURGE Premium Cinematic Gym Interior"
          className="w-full h-full object-cover object-[75%_50%] md:object-right select-none animate-fade-in"
          referrerPolicy="no-referrer"
        />

        {/* Gradual Left-to-Right cinematic gradient overlay for text readability (dark left -> transparent right) */}
        <div 
          className="absolute inset-0 z-10" 
          style={{ 
            background: 'linear-gradient(to right, rgba(5, 5, 5, 1) 0%, rgba(5, 5, 5, 0.98) 35%, rgba(5, 5, 5, 0.65) 65%, rgba(5, 5, 5, 0.1) 100%)' 
          }} 
        />

        {/* Additional mobile-focused bottom-to-top gradient for compact screens */}
        <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark via-cyber-dark/70 to-transparent sm:hidden z-10" />

        {/* Technical grid lines overlay at ultra-low opacity to emphasize high-tech biometric vibe */}
        <div 
          className="absolute inset-0 opacity-[0.04] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:30px_30px] z-10" 
          style={{ maskImage: 'radial-gradient(circle, black, transparent 80%)', WebkitMaskImage: 'radial-gradient(circle, black, transparent 80%)' }}
        />

        {/* Ambient aesthetic glow flares behind text for luxury mood */}
        <div className="absolute top-1/4 left-0 w-[400px] h-[400px] rounded-full bg-cyber-red/[0.04] blur-[130px] z-10" />
        <div className="absolute bottom-1/4 left-[10%] w-[500px] h-[500px] rounded-full bg-cyber-red/[0.03] blur-[150px] z-10" />
      </div>

      {/* LEFT SIDE CONTENT: Perfectly aligned, high-contrast, robust screen readability */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-20 relative flex items-center">
        <div className="w-full lg:w-[60%] xl:w-[55%] flex flex-col items-start gap-8 text-left relative">
          
          {/* Cybernetic Badge */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyber-red/10 border border-cyber-red/25 font-mono text-[10px] sm:text-xs tracking-widest text-cyber-red uppercase font-semibold shadow-[0_0_15px_rgba(255,18,29,0.12)]"
          >
            <Flame className="w-3.5 h-3.5 text-cyber-red" />
            <span>POWERSURGE GYM • MIRPUR, DHAKA</span>
          </motion.div>

          {/* Narrative Content Stack with Precise Typography Hierarchy */}
          <div className="space-y-6 md:space-y-7 w-full">
            {/* Primary Headline */}
            <motion.h1
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-display font-black text-5xl sm:text-6xl md:text-7xl lg:text-[76px] xl:text-[84px] tracking-tight text-white leading-[1.05] sm:leading-[1.0] lg:leading-[0.95] uppercase italic"
            >
              UNLEASH YOUR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyber-red via-[#ff212c] to-red-500 font-extrabold not-italic text-glow-red-strong">
                TRUE POWER
              </span>
            </motion.h1>

            {/* Structured Subheadings Block */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="space-y-3"
            >
              {/* Secondary Line */}
              <h2 className="text-lg sm:text-xl md:text-2xl font-display font-black text-white tracking-[0.16em] uppercase italic flex items-center gap-2.5 leading-snug">
                <span className="w-3 h-[2px] bg-cyber-red shrink-0" />
                WHERE STRENGTH MEETS COMMUNITY
              </h2>
              
              {/* Support Line */}
              <p className="text-xs sm:text-sm md:text-base font-mono tracking-[0.18em] text-cyber-red font-semibold uppercase leading-relaxed">
                TRAIN HARDER. GET STRONGER. TRANSFORM FASTER.
              </p>
            </motion.div>

            {/* Premium Athletic Description Paragraph Stack */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="space-y-4 text-gray-300 font-sans text-sm sm:text-base leading-relaxed md:leading-loose font-light max-w-xl drop-shadow-md"
            >
              <p>
                Step into POWERSURGE: Mirpur’s premier duplex fitness biosphere engineered to recalibrate human stamina.
              </p>
              <p className="font-bold text-white uppercase tracking-wider text-sm sm:text-base">
                No excuses. Only results.
              </p>
            </motion.div>
          </div>

          {/* Call To Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto z-30"
          >
            {/* Primary Glowing Button - Liquid Glass CTA */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onJoinClick}
              className="relative px-8 py-3.5 rounded-full bg-gradient-to-r from-black/70 via-cyber-red/15 to-black/70 text-white font-display font-bold uppercase tracking-widest text-xs border border-cyber-red/45 hover:border-cyber-red/90 transition-all duration-300 shadow-[0_0_15px_rgba(255,18,29,0.22)] hover:shadow-[0_0_35px_rgba(255,18,29,0.6)] cursor-pointer backdrop-blur-xl overflow-hidden flex items-center justify-center gap-2 group/hero-btn"
            >
              {/* Soft feedback layer */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-cyber-red/10 to-transparent opacity-0 group-hover/hero-btn:opacity-100 transition-opacity duration-500" />
              
              {/* Infinite liquid shine reflection slide */}
              <motion.span
                initial={{ x: '-150%' }}
                animate={{ x: '150%' }}
                transition={{ repeat: Infinity, repeatType: "loop", duration: 3, ease: "linear" }}
                className="absolute top-0 bottom-0 w-1/2 bg-gradient-to-r from-transparent via-white/15 to-transparent -skew-x-20 pointer-events-none"
              />

              <span className="relative z-10 text-white tracking-widest font-extrabold text-glow-red">
                Unlock Membership
              </span>
              <ArrowRight className="relative z-10 w-3.5 h-3.5 text-cyber-red transition-transform duration-300 group-hover/hero-btn:translate-x-1.5" />
            </motion.button>

            {/* Secondary Glassmorphism Button */}
            <motion.button
              whileHover={{ scale: 1.04, backgroundColor: 'rgba(255, 255, 255, 0.08)' }}
              whileTap={{ scale: 0.96 }}
              onClick={onViewPlansClick}
              className="px-8 py-3.5 rounded-xl border border-white/10 hover:border-cyber-red/50 text-white font-display font-bold uppercase tracking-widest text-xs transition-all duration-300 bg-cyber-dark/60 backdrop-blur-md flex items-center justify-center gap-2 cursor-pointer hover:shadow-[0_0_15px_rgba(255,18,29,0.15)]"
            >
              <span>VIEW PLANS</span>
              <Play className="w-3 h-3 text-cyber-red fill-cyber-red" />
            </motion.button>
          </motion.div>

          {/* Premium trust badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="pt-6 border-t border-white/5 w-full flex flex-wrap items-center gap-6 text-gray-500 font-mono text-[10px] sm:text-xs tracking-wider"
          >
            <div className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-cyber-red/80" />
              <span>ULTRA LUXURY EQUIPMENT</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-cyber-red/80" />
              <span>24/7 BIOMETRIC SYSTEMS</span>
            </div>
          </motion.div>

        </div>
      </div>

    </section>
  );
}

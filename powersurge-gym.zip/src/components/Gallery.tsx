import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ZoomIn, Sparkles, X } from 'lucide-react';
import { GalleryItem } from '../types';

export default function Gallery() {
  const galleryList: GalleryItem[] = [
    {
      id: 'g-1',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/q_auto/496799157_1302051145259509_2234623943472552726_n_pemoax',
      caption: 'Advanced Lat Pull Down & Cable Crossover system.',
      category: 'Arenas',
    },
    {
      id: 'g-2',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/q_auto/497437722_1302371911894099_7209885761091226512_n_bvudgp',
      caption: 'Dynamic fat-burning high-performance cycling station.',
      category: 'Zones',
    },
    {
      id: 'g-3',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/q_auto/497437789_1302371961894094_3989408564050466481_n_wx1wif',
      caption: 'Heavy Duty Super Leg Press & lower body arena.',
      category: 'Arenas',
    },
    {
      id: 'g-4',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/496426061_1302051235259500_7392713532775136060_n_qpe91a',
      caption: 'Polished executive reception & hospitality desk.',
      category: 'Luxury',
    },
    {
      id: 'g-5',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/02a83aa76a5746e7b16951b002950a59_1_1_yj44ox',
      caption: 'Intelligent cardiovascular treadmills & conditioning zone.',
      category: 'Zones',
    },
    {
      id: 'g-6',
      url: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/20252-11142_475862193-1207869151344376-6677645452683177180-n_pckk4x',
      caption: 'Luxurious panoramic prospective of our 6,000 sq ft duplex layout.',
      category: 'Luxury',
    },
  ];

  const categories = ['All', 'Arenas', 'Zones', 'Luxury'];
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [lightboxImage, setLightboxImage] = useState<GalleryItem | null>(null);

  const filteredItems = selectedCategory === 'All'
    ? galleryList
    : galleryList.filter(item => item.category === selectedCategory);

  return (
    <section className="py-24 bg-cyber-gray relative overflow-hidden select-none">
      {/* Dynamic line vector */}
      <div className="absolute inset-x-0 bottom-0 h-[1px] bg-gradient-to-r from-transparent via-cyber-red/20 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <span className="font-mono text-xs tracking-[0.3em] font-semibold text-cyber-red uppercase block">
            VISUAL PORTFOLIO
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white uppercase italic">
            BIOSPHERE <span className="text-cyber-red text-glow-red">GALLERY</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto font-light font-sans">
            A static visual exploration of our premium athletic landscape, designed to ignite your somatic transformation index.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 rounded-xl text-xs font-mono tracking-widest font-bold uppercase transition-all duration-300 border cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-cyber-red border-cyber-red text-white hover:shadow-[0_0_15px_rgba(255,18,29,0.3)]'
                  : 'bg-cyber-dark/40 border-white/5 hover:border-white/10 text-gray-400 hover:text-white'
              }`}
              id={`filter-btn-${cat.toLowerCase()}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, index) => (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                whileHover={{ y: -5 }}
                className="relative group aspect-[1.3] rounded-2xl overflow-hidden glass-card border border-white/5 cursor-pointer shadow-[0_4px_25px_rgba(0,0,0,0.3)]"
                onClick={() => setLightboxImage(item)}
              >
                {/* Image item layout */}
                <img
                  src={item.url}
                  alt={item.caption}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />

                {/* Cybernetic glowing border and dark overlay */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-cyber-dark via-cyber-dark/40 to-transparent p-5 pt-12 opacity-80 group-hover:opacity-95 transition-all duration-300" />

                {/* Hover view finder icon */}
                <div className="absolute top-4 right-4 p-2.5 rounded-xl bg-cyber-dark/80 backdrop-blur-md border border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-[0_0_10px_rgba(255,18,29,0.1)]">
                  <ZoomIn className="w-4 h-4 text-cyber-red" />
                </div>

                {/* Content Overlay */}
                <div className="absolute bottom-5 left-5 right-5 space-y-1 z-10 transition-transform duration-300 group-hover:translate-y-[-2px]">
                  <span className="font-mono text-[9px] tracking-widest text-cyber-red uppercase font-semibold">
                    {item.category}
                  </span>
                  <h4 className="font-display font-bold text-white text-sm sm:text-base tracking-tight leading-snug">
                    {item.caption}
                  </h4>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Full-screen lightbox layout */}
        <AnimatePresence>
          {lightboxImage && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setLightboxImage(null)}
                className="absolute inset-0 bg-black/95 backdrop-blur-md"
              />

              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="relative max-w-4xl max-h-[85vh] overflow-hidden rounded-2xl border border-white/10 z-10 flex flex-col items-center bg-cyber-dark"
              >
                {/* Images */}
                <img
                  src={lightboxImage.url}
                  alt={lightboxImage.caption}
                  className="max-h-[70vh] w-full object-contain"
                  referrerPolicy="no-referrer"
                />

                {/* Lightbox footer bar descriptions */}
                <div className="w-full bg-cyber-dark p-6 border-t border-white/5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="space-y-1">
                    <span className="font-mono text-[9px] tracking-widest text-cyber-red uppercase font-bold">
                      {lightboxImage.category} Reference Node
                    </span>
                    <p className="text-white font-display font-medium text-sm sm:text-base leading-snug">
                      {lightboxImage.caption}
                    </p>
                  </div>
                  <button
                    onClick={() => setLightboxImage(null)}
                    className="p-3 text-xs font-mono tracking-widest font-extrabold text-white bg-cyber-red/20 border border-cyber-red/40 rounded-xl hover:bg-cyber-red hover:text-white transition-all cursor-pointer shadow-[0_0_12px_rgba(255,18,29,0.2)] flex items-center gap-1.5 self-start sm:self-auto"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>SECURE ACCESS LOCK</span>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { Facility } from '../types';

export default function Facilities() {
  const facilitiesList: Facility[] = [
    {
      id: 'duplex',
      title: 'Spacious Duplex Layout',
      desc: 'Architecturally premium 6,000 sq ft dual-level athletic biosphere separating cardio sectors from heavy plate lifting areas.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/497274323_1302051228592834_3864776839946198450_n_zspjm3',
    },
    {
      id: 'cardio',
      title: 'Cardio Zone',
      desc: 'Equipped with high-oxygen commercial treadmills, cross-runners, and elite spin bikes under direct climate control.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/497746423_1302050055259618_6642990313141159028_n_nw5qz5',
    },
    {
      id: 'strength',
      title: 'Strength Training Area',
      desc: 'Equipped with commercial plate-loaded benches, cable resistance stations, and tactical biomechanical machinery.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/q_auto/578266226_1467268032071152_1095507081364679773_n_igyugp',
    },
    {
      id: 'freeweights',
      title: 'Free Weights Section',
      desc: 'Featuring heavy Olympic bars, micro-loading bumper plates, and luxury steel dumbbell stacks from 5kg to 50kg.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/497220404_1302051368592820_4823342106325782193_n_e75gj5',
    },
    {
      id: 'ac',
      title: 'AC Gym Environment',
      desc: 'Full climate-controlled continuous air purification system maintaining sterile somatic oxygen levels.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/498175614_1302051305259493_6455942972817336480_n_z3zysx',
    },
    {
      id: 'steambath',
      title: 'Steam Bath Facility',
      desc: 'Hot steam muscle-recovery therapy chamber to maximize cell detoxification and post-workout neural relief.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/q_auto/578244776_1467268235404465_6749019216473602469_n_jbqmpj',
    },
    {
      id: 'locker',
      title: 'Safe Locker Room',
      desc: 'Assigned smart locking cabinets to completely secure bags, communication devices, and clothing packs.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/497495272_1302051261926164_6244196098650105231_n_easz07',
    },
    {
      id: 'women',
      title: 'Women’s Private Facilities',
      desc: 'Offering a private, complete vanity lounge dressing suite and dedicated wash space for safety and comfort.',
      iconName: '',
      imageUrl: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/497458154_1302051148592842_2163281489364476973_n_gkzfcy',
    },
  ];

  return (
    <section id="facilities" className="py-24 bg-cyber-dark relative overflow-hidden select-none">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-3/4 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-cyber-red/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center md:text-left md:flex md:items-end md:justify-between mb-16 space-y-4 md:space-y-0">
          <div>
            <span className="font-mono text-xs tracking-[0.3em] font-semibold text-cyber-red uppercase block">
              FACILITY ARSENAL
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white mt-2 uppercase italic">
              ENGINEERED FOR <span className="text-cyber-red text-glow-red">PERFECTION</span>
            </h2>
          </div>
          <p className="text-gray-400 font-sans text-sm sm:text-base max-w-md font-light">
            Every module in POWERSURGE is formulated to deliver optimal somatic output, pairing luxurious architectural spatial planning with premium equipment.
          </p>
        </div>

        {/* Facilities Grid with Hover Effects and Animations */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {facilitiesList.map((facility, index) => (
            <motion.div
              key={facility.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              whileHover={{ y: -8 }}
              className="relative group rounded-2xl glass-card bg-[#0a0a0d]/60 border border-white/5 overflow-hidden flex flex-col justify-between shadow-[0_4px_30px_rgba(0,0,0,0.5)] backdrop-blur-sm neon-hover-card cursor-pointer"
            >
              <div>
                {/* Image Container with aspect-ratio */}
                <div className="relative aspect-[4/3] w-full overflow-hidden">
                  {/* Subtle dark overlay to keep image clean and uniform */}
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500 z-10" />
                  
                  {/* Gradient shadow overlay matching layout */}
                  <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#0a0a0d] to-transparent z-10 opacity-90" />
                  
                  <img
                    src={facility.imageUrl}
                    alt={facility.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                    referrerPolicy="no-referrer"
                  />

                  {/* Aesthetic index number */}
                  <div className="absolute top-4 left-4 font-mono text-[10px] text-cyber-red font-bold px-2 py-0.5 rounded bg-cyber-dark/80 border border-cyber-red/25 z-20">
                    M-0{index + 1}
                  </div>
                </div>

                {/* Content Area */}
                <div className="p-6 relative z-20">
                  <h3 className="text-base font-display font-black text-white mb-2 tracking-tight group-hover:text-cyber-red transition-colors uppercase italic">
                    {facility.title}
                  </h3>
                  <p className="text-gray-400 text-xs leading-relaxed font-sans font-light group-hover:text-gray-300 transition-colors">
                    {facility.desc}
                  </p>
                </div>
              </div>

              {/* Bottom active animation line */}
              <div className="w-full h-[3px] bg-gradient-to-r from-cyber-red to-red-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left z-20" />
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}

import { motion } from 'motion/react';

export default function FloatingWhatsApp() {
  const handleClick = () => {
    const gymWhatsAppNumber = '8801904485009'; // POWERSURGE Gym Dhaka Phone Number
    const message = `Hello POWERSURGE Gym! I am interested in joining your Mirpur gym. Please let me know more details about your current promotional packages and visiting schedules. Check-in request.`;
    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${gymWhatsAppNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Radiant ring waves behind button */}
      <span className="absolute -inset-2 rounded-full bg-[#25D366]/20 animate-ping opacity-75" />
      <span className="absolute -inset-1 rounded-full bg-[#25D366]/30 animate-pulse opacity-50" />

      <motion.button
        onClick={handleClick}
        whileHover={{ scale: 1.15, rotate: 6 }}
        whileTap={{ scale: 0.9 }}
        className="relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-[#1ebd5b] to-[#25D366] text-white shadow-[0_4px_22px_rgba(37,211,102,0.5)] border border-white/20 hover:shadow-[0_4px_32px_rgba(37,211,102,0.85)] cursor-pointer group transition-all"
        aria-label="Contact Gym on WhatsApp"
        id="floating-whatsapp-btn"
      >
        {/* Subtle background glow rotating slightly on hover */}
        <span className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/10 to-transparent group-hover:rotate-180 transition-transform duration-700" />
        
        {/* Custom official WhatsApp SVG icon */}
        <svg 
          viewBox="0 0 24 24" 
          className="w-6 h-6 fill-current drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)] text-white"
        >
          <path d="M12.004 2C6.48 2 2 6.48 2 12.004c0 1.872.516 3.612 1.404 5.124L2 22l4.98-1.308c1.476.804 3.168 1.312 4.968 1.312 5.532 0 10.02-4.488 10.02-10.012C22.02 6.488 17.532 2 12.004 2zm0 16.512c-1.572 0-3.084-.424-4.416-1.2l-.312-.192-3.12.816.828-3.024-.216-.336c-.852-1.356-1.308-2.928-1.308-4.572 0-4.668 3.804-8.472 8.472-8.472 4.668 0 8.472 3.804 8.472 8.472 0 4.668-3.168 8.472-8.472 8.472zm4.512-6.528c-.24-.12-1.428-.708-1.644-.792-.216-.072-.372-.12-.528.12-.156.24-.612.792-.744.936-.144.156-.288.168-.528.048-.24-.12-1.008-.372-1.92-1.188-.708-.636-1.188-1.416-1.332-1.656-.144-.24-.012-.372.108-.492.108-.108.24-.288.36-.432.12-.144.156-.24.24-.408.084-.168.036-.312-.024-.432-.06-.12-.528-1.272-.72-1.74-.192-.456-.384-.396-.528-.396-.132 0-.288-.012-.444-.012s-.408.06-.624.288c-.216.228-.828.804-.828 1.968 0 1.164.84 2.292.96 2.448.12.156 1.656 2.532 4.004 3.54.56.24 1 .384 1.344.492.564.18 1.076.156 1.484.096.452-.068 1.428-.588 1.632-1.128.204-.54.204-1.008.144-1.104-.06-.096-.216-.144-.456-.264z" />
        </svg>

        {/* Hover label tool-tip */}
        <span className="absolute right-16 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg bg-cyber-dark/95 border border-[#25D366]/30 text-xs font-mono tracking-wider font-medium text-white opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_0_15px_rgba(37,211,102,0.25)]">
          Instant Fitness Support
        </span>
      </motion.button>
    </div>
  );
}

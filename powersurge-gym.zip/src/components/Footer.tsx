import { PhoneCall, Mail, MapPin, Shield, RefreshCw, Facebook, Instagram, Youtube, Zap } from 'lucide-react';
import { smoothScrollTo } from '../utils/scroll';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="contact" className="bg-[#030303] text-white pt-20 pb-8 relative overflow-hidden select-none border-t border-white/5">
      {/* Dynamic diagonal lasers vectors back decoration */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[radial-gradient(ellipse_at_center,rgba(255,18,29,0.05),transparent_60%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16">
        
        {/* Column 1: Brand & Bio (lg:col-span-4) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              {/* High-Performance Neon Logo Icon Badge */}
              <div className="relative w-8 h-8 rounded-lg bg-cyber-red/10 border border-cyber-red/40 flex items-center justify-center shadow-[0_0_12px_rgba(255,18,29,0.15)] overflow-hidden">
                <span className="absolute inset-0 bg-gradient-to-tr from-cyber-red/20 to-transparent opacity-50" />
                <img
                  src="https://i.ibb.co.com/pvQkLRWX/edited-photo.png"
                  alt="POWERSURGE Gym Logo"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-display text-2xl font-black tracking-tighter text-white italic">
                POWER<span className="text-cyber-red not-italic font-extrabold text-glow-red">SURGE</span>
              </span>
            </div>
            <span className="block font-mono text-[9px] tracking-widest text-zinc-500 font-bold uppercase">
              MIRPUR • DHAKA • BANGLADESH
            </span>
          </div>
          <p className="text-gray-400 text-sm leading-relaxed font-sans font-light max-w-sm">
            Mirpur's premium duplex physical transformation biosphere. 6,000 sq ft across separate functional levels with steam baths, AC, lockers, and expert coaching.
          </p>
          
          <div className="space-y-3 font-mono text-[10px] text-gray-500">
            <div className="flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-cyber-red" />
              <span>LICENSED SPORTS SCIENCE FACILITY</span>
            </div>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 text-cyber-red" />
              <span>NODE SECURED — ONLINE STATUS</span>
            </div>
          </div>

          {/* Social Links under branding */}
          <div className="pt-2 flex items-center gap-4">
            <a
              href="https://www.facebook.com/profile.php?id=100063639069967"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-cyber-red hover:bg-cyber-red/10 text-zinc-400 hover:text-white flex items-center justify-center transition-all duration-300"
              aria-label="Follow POWERSURGE Page on Facebook"
            >
              <Facebook className="w-4 h-4" />
            </a>
            <a
              href="https://www.facebook.com/groups/602385294352949/members/admins"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-cyber-red hover:bg-cyber-red/10 text-zinc-400 hover:text-white flex items-center justify-center transition-all duration-300 font-mono text-[9px] font-bold"
              aria-label="POWERSURGE Facebook Group"
            >
              GRP
            </a>
            <a
              href="https://www.instagram.com/powersurge_gym_01?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-cyber-red hover:bg-cyber-red/10 text-zinc-400 hover:text-white flex items-center justify-center transition-all duration-300"
              aria-label="Follow POWERSURGE on Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Column 2: Contact Info (lg:col-span-4) */}
        <div className="lg:col-span-4 space-y-6">
          <h4 className="font-display font-black text-sm tracking-widest text-cyber-red uppercase font-bold">
            CONTACT METRICS
          </h4>
          
          <ul className="space-y-4 text-sm font-sans font-light text-gray-400">
            <li className="flex gap-3 items-start">
              <span className="p-1.5 rounded-lg bg-cyber-dark border border-white/5 text-cyber-red mt-0.5" id="pin-icon-box">
                <MapPin className="w-4 h-4" />
              </span>
              <div>
                <span className="block font-semibold text-white uppercase text-xs">Gym Address</span>
                <span className="text-xs sm:text-sm leading-snug block">
                  House 377/3, Barek Mollah Mor <br />
                  Mirpur-2, Dhaka, Bangladesh
                </span>
              </div>
            </li>

            <li className="flex gap-3 items-start">
              <span className="p-1.5 rounded-lg bg-cyber-dark border border-white/5 text-cyber-red mt-0.5" id="phone-icon-box">
                <PhoneCall className="w-4 h-4" />
              </span>
              <div>
                <span className="block font-semibold text-white uppercase text-xs">Direct Core</span>
                <a href="tel:+8801904485009" className="text-xs sm:text-sm hover:text-cyber-red transition-all block font-mono">
                  +880 1904-485009
                </a>
              </div>
            </li>

            <li className="flex gap-3 items-start">
              <span className="p-1.5 rounded-lg bg-cyber-dark border border-white/5 text-cyber-red mt-0.5" id="mail-icon-box">
                <Mail className="w-4 h-4" />
              </span>
              <div>
                <span className="block font-semibold text-white uppercase text-xs">Secure Dispatch</span>
                <a href="mailto:Powersurge@gmail.com" className="text-xs sm:text-sm hover:text-cyber-red transition-all block font-mono">
                  Powersurge@gmail.com
                </a>
              </div>
            </li>
          </ul>
        </div>

        {/* Column 3: Google Map embed (lg:col-span-4) */}
        <div className="lg:col-span-4 space-y-4">
          <h4 className="font-display font-black text-sm tracking-widest text-cyber-red uppercase font-bold">
            GPS GEOMETRICS
          </h4>
          
          {/* Framed Maps Embed with a premium dark styling cover */}
          <div className="w-full h-[180px] rounded-xl overflow-hidden border border-white/5 shadow-[0_0_15px_rgba(0,0,0,0.5)] relative bg-cyber-dark">
            <iframe
              title="POWERSURGE Coordinates Map"
              src="https://maps.google.com/maps?q=Barek%20Mollah%20Mor,%20Mirpur-2,%20Dhaka&t=&z=16&ie=UTF8&iwloc=&output=embed"
              className="w-full h-full border-none grayscale invert contrast-110 opacity-75 hover:opacity-100 transition-opacity duration-300"
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

      </div>

      {/* Footer copyright section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-white/5 text-center flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <p className="font-mono text-[10px] sm:text-xs text-gray-500 tracking-wider">
          &copy; {currentYear} POWERSURGE GYM DHAKA. ALL TRANSFERS REGISTERED.
        </p>
        <div className="flex justify-center gap-6 font-mono text-[10px] text-gray-500 tracking-wider">
          <a 
            href="#home" 
            onClick={(e) => {
              e.preventDefault();
              smoothScrollTo('#home', 1200);
            }} 
            className="hover:text-cyber-red transition-all uppercase cursor-pointer"
          >
            Access Protocols
          </a>
          <span>|</span>
          <a 
            href="#facilities" 
            onClick={(e) => {
              e.preventDefault();
              smoothScrollTo('#facilities', 1200);
            }} 
            className="hover:text-cyber-red transition-all uppercase cursor-pointer"
          >
            Security Rules
          </a>
        </div>
      </div>
    </footer>
  );
}

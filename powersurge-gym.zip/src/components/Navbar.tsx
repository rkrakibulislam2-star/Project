import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, Zap } from 'lucide-react';
import { smoothScrollTo } from '../utils/scroll';

interface NavbarProps {
  onJoinClick: () => void;
}

export default function Navbar({ onJoinClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [hoveredSection, setHoveredSection] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }

      // Scroll spy for current visible section
      const sections = ['home', 'facilities', 'pricing', 'trainers', 'contact'];
      const scrollPos = window.scrollY + window.innerHeight / 3;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Run initially to configure section position
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Home', href: '#home' },
    { label: 'Facilities', href: '#facilities' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Trainers', href: '#trainers' },
    { label: 'Contact', href: '#contact' },
  ];

  const visibleSection = hoveredSection ?? activeSection;

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 border-b ${
          isScrolled
            ? 'bg-cyber-dark/85 backdrop-blur-lg border-cyber-red/20 shadow-[0_12px_40px_rgba(0,0,0,0.95)] shadow-cyber-red/5 py-3'
            : 'bg-cyber-dark/60 backdrop-blur-md border-cyber-red/10 shadow-[0_4px_30px_rgba(0,0,0,0.6)] py-5'
        }`}
        id="navbar-header"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo Brand */}
          <motion.a 
            href="#home" 
            whileTap={{ scale: 0.97 }}
            onClick={(e) => {
              e.preventDefault();
              smoothScrollTo('#home', 1200);
            }}
            className="flex items-center gap-2.5 group"
          >
            {/* High-Performance Neon Logo Icon Badge */}
            <div className="relative w-12 h-12 rounded-2xl bg-cyber-red/10 border border-cyber-red/35 flex items-center justify-center transition-all duration-300 group-hover:border-cyber-red group-hover:bg-cyber-red/20 shadow-[0_0_18px_rgba(255,18,29,0.2)] group-hover:shadow-[0_0_24px_rgba(255,18,29,0.45)] overflow-hidden">
              <span className="absolute inset-0 bg-gradient-to-tr from-cyber-red/20 to-transparent opacity-50 group-hover:opacity-80 transition-opacity" />
              <img
                src="https://i.ibb.co.com/pvQkLRWX/edited-photo.png"
                alt="POWERSURGE Gym Logo"
                className="w-full h-full object-cover transition-all duration-300 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
            </div>

            <span className="relative font-display text-2xl font-black tracking-tighter text-white italic transition-all duration-300 group-hover:text-glow-red">
              POWER
              <span className="text-cyber-red not-italic font-extrabold text-glow-red">SURGE</span>
              {/* Futuristic small indicator dots */}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-cyber-red transition-all duration-300 group-hover:w-full" />
            </span>
          </motion.a>

          {/* Desktop Nav Items - Futuristic Pill Bar with Glowing Neon Spotlight Indicators */}
          <nav 
            className="hidden md:flex items-center gap-1.5 px-3 h-11 rounded-full bg-[#0a0a0c]/90 border border-white/10 backdrop-blur-2xl shadow-[inset_0_1px_1px_rgba(255,255,255,0.08),0_12px_36px_rgba(0,0,0,0.9)] relative"
            onMouseLeave={() => setHoveredSection(null)}
          >
            {menuItems.map((item) => {
              const sectionId = item.href.replace('#', '');
              const isCurrent = visibleSection === sectionId;

              return (
                <motion.a
                  key={item.label}
                  href={item.href}
                  whileTap={{ scale: 0.94 }}
                  onMouseEnter={() => setHoveredSection(sectionId)}
                  onClick={(e) => {
                    e.preventDefault();
                    smoothScrollTo(item.href, 1200);
                  }}
                  className={`relative px-4 sm:px-4.5 h-full flex items-center justify-center font-display text-[11px] tracking-[0.18em] uppercase font-bold transition-all duration-350 select-none cursor-pointer z-10 ${
                    isCurrent ? 'text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <span className="relative z-20">{item.label}</span>
                  
                  {/* Sliding Indicator Animation */}
                  {isCurrent && (
                    <>
                      {/* Top horizontal glowing neon white indicator bar */}
                      <motion.div
                        layoutId="nav-glow-top-bar"
                        className="absolute top-0 left-3 right-3 h-[2px] bg-[#fdfdfd] rounded-full shadow-[0_0_12px_rgba(255,255,255,1),0_0_4px_rgba(255,255,255,1)] z-20"
                        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                      />
                      
                      {/* Smooth downward reflecting spotlight cone light gradient */}
                      <motion.div
                        layoutId="nav-glow-spotlight"
                        className="absolute inset-x-0 top-0 h-9 bg-gradient-to-b from-white/[0.08] to-transparent pointer-events-none z-10"
                        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                        style={{
                          clipPath: 'polygon(15% 0%, 85% 0%, 100% 100%, 0% 100%)'
                        }}
                      />
                    </>
                  )}
                </motion.a>
              );
            })}
          </nav>

          {/* Glowing Join CTA & Mobile menu toggle */}
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onJoinClick}
              className="relative hidden sm:flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-black/60 via-cyber-red/10 to-black/60 text-white font-display text-xs font-bold uppercase tracking-wider border border-cyber-red/40 hover:border-cyber-red transition-all duration-300 shadow-[0_0_15px_rgba(255,18,29,0.15)] hover:shadow-[0_0_25px_rgba(255,18,29,0.45)] cursor-pointer backdrop-blur-xl overflow-hidden group/btn"
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-cyber-red/10 to-transparent opacity-0 group-hover/btn:opacity-100 transition-opacity duration-500" />
              <motion.span
                initial={{ x: '-150%' }}
                animate={{ x: '150%' }}
                transition={{ repeat: Infinity, repeatType: "loop", duration: 3, ease: "linear" }}
                className="absolute top-0 bottom-0 w-1/2 bg-gradient-to-r from-transparent via-white/12 to-transparent -skew-x-20 pointer-events-none"
              />
              <span className="relative z-10 text-white tracking-wider font-black text-glow-red">Unlock Membership</span>
              <ArrowRight className="relative z-10 w-3.5 h-3.5 text-cyber-red transition-transform duration-300 group-hover/btn:translate-x-1" />
            </motion.button>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 md:hidden text-gray-400 hover:text-white transition-colors"
              aria-label="Toggle Mobile Menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu glass dropdown */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="md:hidden glass-nav border-t border-white/5 absolute top-full left-0 right-0 overflow-hidden"
            >
              <nav className="flex flex-col px-6 py-8 gap-5 bg-cyber-dark/95">
                {menuItems.map((item) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => {
                      e.preventDefault();
                      setIsOpen(false);
                      // Extra delay to let menu close slightly so scroll aligns perfectly
                      setTimeout(() => {
                        smoothScrollTo(item.href, 1200);
                      }, 150);
                    }}
                    className="font-mono text-sm tracking-widest text-gray-200 hover:text-cyber-red transition-colors py-1.5 cursor-pointer block"
                  >
                    {item.label}
                  </motion.a>
                ))}
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onJoinClick();
                  }}
                  className="relative w-full mt-4 flex items-center justify-center gap-2 px-3.5 py-3.5 rounded-full bg-gradient-to-r from-black/60 via-cyber-red/10 to-black/60 text-white font-display text-xs font-bold uppercase tracking-wider border border-cyber-red/50 hover:border-cyber-red transition-all duration-300 shadow-[0_4px_15px_rgba(255,18,29,0.22)] cursor-pointer backdrop-blur-xl overflow-hidden group/btn"
                >
                  <motion.span
                    initial={{ x: '-150%' }}
                    animate={{ x: '150%' }}
                    transition={{ repeat: Infinity, repeatType: "loop", duration: 3, ease: "linear" }}
                    className="absolute top-0 bottom-0 w-1/2 bg-gradient-to-r from-transparent via-white/12 to-transparent -skew-x-20 pointer-events-none"
                  />
                  <span className="relative z-10 text-white tracking-wider font-extrabold text-glow-red">Unlock Membership</span>
                </button>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}

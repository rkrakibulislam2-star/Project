import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { Award, Zap, Shield, Sparkles } from 'lucide-react';

interface StatCounterProps {
  value: number;
  suffix?: string;
  duration?: number;
}

function StatCounter({ value, suffix = '', duration = 2000 }: StatCounterProps) {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(elementRef, { once: true, margin: '-100px' });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * value));
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        setCount(value);
      }
    };
    requestAnimationFrame(step);
  }, [isInView, value, duration]);

  return (
    <div ref={elementRef} className="text-4xl sm:text-5xl font-display font-black tracking-tight text-white mb-1.5 italic font-bold">
      <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-gray-200">
        {count}
      </span>
      <span className="text-cyber-red ml-0.5 text-glow-red">{suffix}</span>
    </div>
  );
}

export default function WhyChoose() {
  const features = [
    {
      icon: <Award className="w-5 h-5 text-cyber-red" />,
      title: 'World-Class Bio-Intelligence',
      desc: 'Our neural trackers and algorithmic cardio equipment sync directly to your health metrics for real-time adjustments.',
    },
    {
      icon: <Zap className="w-5 h-5 text-cyber-red" />,
      title: 'Tactical Peak Performance',
      desc: 'Our high-intensity workout sectors offer strategic atmospheric conditioning to amplify cellular mitochondrial output.',
    },
    {
      icon: <Shield className="w-5 h-5 text-cyber-red" />,
      title: 'Uncompromised Deluxe Luxury',
      desc: 'Premium biometric security gateways, smart responsive climate systems, and private bespoke recovery areas.',
    },
  ];

  return (
    <section className="py-24 bg-cyber-gray relative overflow-hidden select-none">
      {/* Dynamic graphic lines */}
      <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-cyber-red/20 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-[1px] bg-gradient-to-r from-transparent via-cyber-red/20 to-transparent" />

      {/* Decorative blurred red accent */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[350px] h-[350px] rounded-full bg-cyber-red/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
        
        {/* Left column: Text Content */}
        <div className="lg:col-span-7 space-y-10">
          <div>
            <span className="font-mono text-xs tracking-[0.25em] font-semibold text-cyber-red uppercase block">
              POWERSURGE BIOSPHERE
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white mt-2 uppercase italic">
              BEYOND ATHLETICS. <br />
              <span className="text-cyber-red text-glow-red">EVOLUTIONIZED.</span>
            </h2>
            <p className="text-gray-400 font-sans text-sm sm:text-base mt-4 font-light max-w-2xl leading-relaxed">
              We did not build another simple fitness studio. We engineered an atmospheric biosphere where human physiology is optimized, accelerated, and luxury-infused.
            </p>
          </div>

          {/* Core premium features list */}
          <div className="space-y-6">
            {features.map((feat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.15 }}
                className="flex gap-4 p-5 rounded-xl bg-cyber-dark/40 border border-white/5 hover:border-white/10 transition-colors"
                id={`feature-node-${i}`}
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-cyber-red/10 border border-cyber-red/20 flex items-center justify-center">
                  {feat.icon}
                </div>
                <div>
                  <h4 className="text-base font-display font-bold text-white uppercase tracking-wide">
                    {feat.title}
                  </h4>
                  <p className="text-gray-400 text-xs sm:text-sm font-light mt-1.5 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Right column: Stat Modules Blocks & Mini Poster / Custom Grid */}
        <div className="lg:col-span-5 relative">
          
          {/* Bento-style stats grid */}
          <div className="grid grid-cols-2 gap-4">
            
            {/* Stat 1 */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="p-6 rounded-2xl bg-cyber-dark/80 border border-white/5 flex flex-col justify-between min-h-[140px] hover:border-cyber-red/30 transition-all shadow-[inset_0_2px_4px_rgba(255,255,255,0.01)]"
            >
              <StatCounter value={15000} suffix="+" />
              <div>
                <span className="font-mono text-[10px] tracking-widest text-[#888] uppercase block">
                  Active Community
                </span>
                <span className="font-display text-sm font-bold text-gray-300 uppercase mt-0.5 block">
                  Facebook Fans
                </span>
              </div>
            </motion.div>

            {/* Stat 2 */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="p-6 rounded-2xl bg-cyber-dark/80 border border-white/5 flex flex-col justify-between min-h-[140px] hover:border-cyber-red/30 transition-all shadow-[inset_0_2px_4px_rgba(255,255,255,0.01)]"
            >
              <StatCounter value={2000} suffix="+" />
              <div>
                <span className="font-mono text-[10px] tracking-widest text-[#888] uppercase block">
                  Verified Check-ins
                </span>
                <span className="font-display text-sm font-bold text-gray-300 uppercase mt-0.5 block">
                  Member Visits
                </span>
              </div>
            </motion.div>

            {/* Stat 3 */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="p-6 rounded-2xl bg-cyber-dark/80 border border-white/5 flex flex-col justify-between min-h-[140px] hover:border-cyber-red/30 transition-all shadow-[inset_0_2px_4px_rgba(255,255,255,0.01)]"
            >
              <div className="text-4xl sm:text-5xl font-display font-black tracking-tight text-white mb-1.5 italic font-bold">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-gray-200">
                  4.4
                </span>
                <span className="text-cyber-red ml-0.5 text-glow-red">★</span>
              </div>
              <div>
                <span className="font-mono text-[10px] tracking-widest text-[#888] uppercase block">
                  Average Rating
                </span>
                <span className="font-display text-sm font-bold text-gray-300 uppercase mt-0.5 block">
                  Member Reviews
                </span>
              </div>
            </motion.div>

            {/* Stat 4 */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="p-6 rounded-2xl bg-cyber-dark/80 border border-white/5 flex flex-col justify-between min-h-[140px] hover:border-cyber-red/30 transition-all shadow-[inset_0_2px_4px_rgba(255,255,255,0.01)]"
            >
              <StatCounter value={80} suffix="%" />
              <div>
                <span className="font-mono text-[10px] tracking-widest text-[#888] uppercase block">
                  Recommendation
                </span>
                <span className="font-display text-sm font-bold text-gray-300 uppercase mt-0.5 block">
                  Active Rate
                </span>
              </div>
            </motion.div>

          </div>

          {/* Small modern secondary aesthetic details */}
          <div className="absolute -top-12 -right-12 w-32 h-32 border-r border-t border-cyber-red/30 pointer-events-none rounded-tr-3xl" />
          <div className="absolute -bottom-12 -left-12 w-32 h-32 border-l border-b border-cyber-red/30 pointer-events-none rounded-bl-3xl" />
          
        </div>

      </div>
    </section>
  );
}

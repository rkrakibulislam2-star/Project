import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Scale, Info, Activity } from 'lucide-react';

export default function BMICalculator() {
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);
  const [status, setStatus] = useState('');
  const [advice, setAdvice] = useState('');

  const calculateBMI = (e: React.FormEvent) => {
    e.preventDefault();
    const h = parseFloat(height);
    const w = parseFloat(weight);

    if (isNaN(h) || isNaN(w) || h <= 0 || w <= 0) {
      alert('Please enter valid measurements.');
      return;
    }

    let calculatedBmi = 0;
    if (unit === 'metric') {
      // Height in cm, weight in kg. Regular BMI formula: kg / m^2
      const heightInMeters = h / 100;
      calculatedBmi = w / (heightInMeters * heightInMeters);
    } else {
      // Height in inches, weight in lbs. Formula: (lbs / inches^2) * 703
      calculatedBmi = (w / (h * h)) * 703;
    }

    calculatedBmi = Math.round(calculatedBmi * 10) / 10;
    setBmi(calculatedBmi);

    // Interpret BMI status & supply high end futuristic instructions
    if (calculatedBmi < 18.5) {
      setStatus('Somatic Deficit (Underweight)');
      setAdvice('Recommended Protocol: Caloric surplus hyper-fuel alongside heavy progressive resistance workouts to stimulate skeletal muscle hypertrophy.');
    } else if (calculatedBmi >= 18.5 && calculatedBmi < 25) {
      setStatus('Optimal Biometrics (Normal)');
      setAdvice('Recommended Protocol: Maintenance macros or clean recomposition. Excellent physical equilibrium detected. Push for higher relative strength indexes.');
    } else if (calculatedBmi >= 25 && calculatedBmi < 30) {
      setStatus('Somatic Surplus (Overweight)');
      setAdvice('Recommended Protocol: Modest caloric deficit, high volume weight lifting mixed with lactic-acid thresholds or high oxygen-capacity cardio cycles.');
    } else {
      setStatus('Hyper Somatic Mass (Obese)');
      setAdvice('Recommended Protocol: Targeted fat-metabolism zones, strictly regulated low glycemic nutrition, and strategic joint-safe cardio vectors.');
    }
  };

  const getPercentageForGauge = (val: number) => {
    // normal ranges of gauge from 15 to 35
    const min = 15;
    const max = 35;
    const percentage = ((val - min) / (max - min)) * 100;
    return Math.max(0, Math.min(100, percentage));
  };

  const getStatusColorClass = (val: number) => {
    if (val < 18.5) return 'text-yellow-400';
    if (val >= 18.5 && val < 25) return 'text-green-400';
    if (val >= 25 && val < 30) return 'text-orange-400';
    return 'text-cyber-red';
  };

  const clearCalculator = () => {
    setHeight('');
    setWeight('');
    setBmi(null);
    setStatus('');
    setAdvice('');
  };

  return (
    <section className="py-24 bg-cyber-dark relative overflow-hidden select-none">
      {/* Decorative cyber line overlay */}
      <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-gradient-to-b from-transparent via-cyber-red/20 to-transparent" />

      {/* Decorative cyber grid in corner */}
      <div className="absolute top-10 right-10 w-24 h-24 bg-[radial-gradient(ellipse_at_center,rgba(255,18,29,0.15),transparent_60%)] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <span className="font-mono text-xs tracking-[0.3em] font-semibold text-cyber-red uppercase block">
            BIOMETRIC ASSESSMENT
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white mt-1 uppercase italic">
            NEURAL <span className="text-cyber-red text-glow-red">BMI ENGINE</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto font-light font-sans">
            Instantly formulate your somatic starting index. Input height and weight variables to receive bespoke fitness coaching suggestions.
          </p>
        </div>

        {/* Calculator layout grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Block: Inputs Form (md:col-span-6) */}
          <div className="md:col-span-6 p-6 sm:p-8 rounded-2xl glass-card border border-white/5 flex flex-col justify-between">
            <form onSubmit={calculateBMI} className="space-y-6">
              
              {/* Unit Selector Toggle */}
              <div className="flex bg-cyber-dark/80 p-1 rounded-xl border border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setUnit('metric');
                    clearCalculator();
                  }}
                  className={`flex-1 text-center py-2 rounded-lg font-mono text-[10px] sm:text-xs tracking-wider font-semibold transition-all cursor-pointer ${
                    unit === 'metric'
                      ? 'bg-cyber-red text-white shadow-[0_0_10px_rgba(255,18,29,0.3)]'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  METRIC SYSTEM (CM/KG)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUnit('imperial');
                    clearCalculator();
                  }}
                  className={`flex-1 text-center py-2 rounded-lg font-mono text-[10px] sm:text-xs tracking-wider font-semibold transition-all cursor-pointer ${
                    unit === 'imperial'
                      ? 'bg-cyber-red text-white shadow-[0_0_10px_rgba(255,18,29,0.3)]'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  IMPERIAL SYSTEM (IN/LBS)
                </button>
              </div>

              {/* Height Input Block */}
              <div className="space-y-2">
                <label className="font-mono text-xs tracking-widest text-gray-300 uppercase flex items-center justify-between">
                  <span>Height Variable</span>
                  <span className="text-cyber-red font-semibold">
                    {unit === 'metric' ? '[ Centimeters ]' : '[ Inches ]'}
                  </span>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono text-xs pointer-events-none">[H]</span>
                  <input
                    type="number"
                    step="any"
                    required
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    placeholder={unit === 'metric' ? 'e.g. 178' : 'e.g. 70'}
                    className="w-full bg-cyber-dark/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-600 focus:outline-none focus:border-cyber-red focus:ring-1 focus:ring-cyber-red transition-all"
                  />
                </div>
              </div>

              {/* Weight Input Block */}
              <div className="space-y-2">
                <label className="font-mono text-xs tracking-widest text-gray-300 uppercase flex items-center justify-between">
                  <span>Weight Variable</span>
                  <span className="text-cyber-red font-semibold">
                    {unit === 'metric' ? '[ Kilograms ]' : '[ Pounds ]'}
                  </span>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono text-xs pointer-events-none">[W]</span>
                  <input
                    type="number"
                    step="any"
                    required
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder={unit === 'metric' ? 'e.g. 75' : 'e.g. 165'}
                    className="w-full bg-cyber-dark/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-600 focus:outline-none focus:border-cyber-red focus:ring-1 focus:ring-cyber-red transition-all"
                  />
                </div>
              </div>

              {/* Action Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-gradient-to-r from-cyber-red to-red-600 text-white font-display font-bold uppercase tracking-widest py-3.5 rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_15px_rgba(255,18,29,0.4)] cursor-pointer transition-all"
              >
                <Activity className="w-4 h-4 text-white" />
                <span>FORMULATE BMI</span>
              </motion.button>

            </form>
          </div>

          {/* Right Block: Real-time Diagnostics Display (md:col-span-6) */}
          <div className="md:col-span-6 p-6 sm:p-8 rounded-2xl glass-card-red border border-cyber-red/10 flex flex-col justify-center min-h-[300px]">
            <AnimatePresence mode="wait">
              {bmi === null ? (
                <motion.div
                  key="empty-state"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center space-y-4 self-center"
                >
                  <div className="w-12 h-12 rounded-full border border-white/5 bg-white/5 flex items-center justify-center mx-auto text-gray-400">
                    <Scale className="w-6 h-6 text-cyber-red/75 animate-pulse" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-gray-200 uppercase tracking-widest text-sm">
                      Awaiting Neural Matrix
                    </h4>
                    <p className="text-gray-500 text-xs font-light max-w-[240px] mx-auto leading-relaxed">
                      Please enter height and weight variables and click "Formulate BMI" to load diagnostics.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="result-state"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="space-y-6"
                >
                  {/* Result Header */}
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-widest text-cyber-red uppercase font-semibold">
                      Diagnostic Output
                    </span>
                    <button
                      onClick={clearCalculator}
                      className="font-mono text-[9px] tracking-wider text-gray-400 hover:text-white uppercase hover:underline"
                    >
                      Clear Index
                    </button>
                  </div>

                  {/* Core Large Score display */}
                  <div className="flex items-baseline gap-2">
                    <span className="text-6xl sm:text-7xl font-display font-black tracking-tighter text-white">
                      {bmi}
                    </span>
                    <span className="font-mono text-xs text-gray-400 uppercase">
                      Index Points
                    </span>
                  </div>

                  {/* BMI Status Gauge Indicator */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="text-gray-400">Status Classification</span>
                      <span className={`font-bold ${getStatusColorClass(bmi)} uppercase`}>
                        {status}
                      </span>
                    </div>

                    {/* Progress slider bar gauge */}
                    <div className="w-full h-2 rounded-full bg-cyber-dark overflow-hidden relative border border-white/5">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${getPercentageForGauge(bmi)}%` }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className="h-full bg-gradient-to-r from-yellow-500 via-green-500 to-cyber-red"
                      />
                      {/* Subdividers */}
                      <div className="absolute top-0 bottom-0 left-[17.5%] w-[1px] bg-cyber-dark" /> {/* Underweight / Normal boundary */}
                      <div className="absolute top-0 bottom-0 left-[50%] w-[1px] bg-cyber-dark" />   {/* Normal / Overweight boundary */}
                      <div className="absolute top-0 bottom-0 left-[75%] w-[1px] bg-cyber-dark" />   {/* Overweight / Obese boundary */}
                    </div>

                    <div className="flex justify-between text-[8px] sm:text-[9px] font-mono text-gray-500 pt-0.5 uppercase">
                      <span>15 (Under)</span>
                      <span>18.5 (Normal)</span>
                      <span>25.0 (Surplus)</span>
                      <span>30.0 (Obese)</span>
                    </div>
                  </div>

                  {/* Bespoke AI advice panel */}
                  <div className="p-4 rounded-xl bg-cyber-dark/90 border border-white/5 flex gap-3 text-xs leading-relaxed text-gray-300">
                    <Info className="w-5 h-5 text-cyber-red flex-shrink-0 mt-0.5" />
                    <div>
                      <span className="font-mono font-bold block text-white text-[10px] tracking-wider uppercase mb-1">
                        Somatic Directive
                      </span>
                      <p className="font-light text-gray-400">{advice}</p>
                    </div>
                  </div>

                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Check, Flame, Zap, Crown, Sparkles, Clock, AlertCircle } from 'lucide-react';
import { PlanName } from '../types';

interface PricingProps {
  onPlanSelect: (plan: PlanName) => void;
}

export default function Pricing({ onPlanSelect }: PricingProps) {
  // Local countdown and seat animation simulation for Eid special urgency
  const [timeLeft, setTimeLeft] = useState({ hours: 14, minutes: 32, seconds: 45 });
  const [seatsLeft, setSeatsLeft] = useState(6);
  const [selectedOfferOption, setSelectedOfferOption] = useState<'10months' | '16months'>('10months');

  useEffect(() => {
    // Elegant ticking clock simulation
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 14, minutes: 32, seconds: 45 }; // Reset to maintain aesthetic tension
      });
    }, 1000);

    // Random seat decrement for real urgency simulation
    const seatInterval = setInterval(() => {
      setSeatsLeft((prev) => (prev > 3 ? prev - 1 : 6));
    }, 45000);

    return () => {
      clearInterval(interval);
      clearInterval(seatInterval);
    };
  }, []);

  const corePlans = [
    {
      name: 'Admission + 2 Months' as PlanName,
      price: '৳1,500',
      duration: '2 Months',
      badge: 'CORE',
      desc: 'Quick entry booster condition',
      features: [
        'Full gym access',
        'Cardio + strength zones',
        'Steam bath access',
        'Basic trainer support',
      ],
      icon: <Zap className="w-5 h-5 text-gray-400 group-hover:text-cyber-red transition-colors" />,
      glow: false,
    },
    {
      name: 'Admission + 4 Months' as PlanName,
      price: '৳2,000',
      duration: '4 Months',
      badge: 'OVERDRIVE',
      desc: 'Most popular plan',
      features: [
        'Full gym access',
        'Cardio + strength zones',
        'Steam bath access',
        'Priority trainer guidance',
        'Locker access',
      ],
      icon: <Flame className="w-5 h-5 text-cyber-red animate-pulse" />,
      glow: true,
      bestValue: true,
    },
    {
      name: 'Admission + 6 Months' as PlanName,
      price: '৳2,500',
      duration: '6 Months',
      badge: 'TITAN',
      desc: 'Absolute physical transformation',
      features: [
        'Full gym access',
        'Cardio + strength zones',
        'Steam bath access',
        'Advanced trainer support',
        'Supplement guidance support',
      ],
      icon: <Crown className="w-5 h-5 text-gray-400 group-hover:text-cyber-red transition-colors" />,
      glow: false,
    },
    {
      name: 'Admission + 12 Months' as PlanName,
      price: '৳3,000',
      duration: '12 Months',
      badge: 'PREMIUM',
      desc: 'Annual ultimate performance',
      features: [
        'Full gym access',
        'All facilities included',
        'Steam bath + locker',
        'Full trainer support',
        'Priority assistance',
      ],
      icon: <Sparkles className="w-5 h-5 text-amber-500" />,
      glow: false,
      premium: true,
    },
  ];

  return (
    <section id="pricing" className="py-28 bg-[#040406] relative overflow-hidden select-none border-t border-b border-white/5">
      {/* Absolute dynamic glow nodes */}
      <div className="absolute top-1/4 -left-1/4 w-[600px] h-[600px] rounded-full bg-cyber-red/5 blur-[150px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-1/4 w-[600px] h-[600px] rounded-full bg-cyber-red/5 blur-[150px] pointer-events-none" />
      
      {/* Abstract radial grids cover background */}
      <div className="absolute inset-x-0 top-0 h-[500px] bg-[radial-gradient(circle_at_center,rgba(255,18,29,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-24 space-y-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-cyber-red/5 border border-cyber-red/20 rounded-full"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyber-red animate-ping" />
            <span className="font-mono text-[9px] sm:text-[10px] tracking-[0.3em] font-extrabold text-cyber-red uppercase">
              Flexible pricing modules
            </span>
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white uppercase italic"
          >
            Membership <span className="text-cyber-red text-glow-red">Plans</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-zinc-400 text-xs sm:text-sm max-w-md mx-auto font-light font-sans leading-relaxed"
          >
            Choose the plan that fits your fitness journey. Each card incorporates high-performance custom perks.
          </motion.p>
        </div>

        {/* Core Pricing Grid (Mockup aesthetic with overlapping floating circle badges) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10 lg:gap-8 items-stretch max-w-7xl mx-auto mb-28 pt-8">
          {corePlans.map((plan, index) => {
            const isGlow = plan.glow;
            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: index * 0.1 }}
                whileHover={{ 
                  y: -12, 
                  scale: 1.025,
                }}
                className={`relative flex flex-col justify-between px-6 pb-8 pt-12 rounded-[2rem] cursor-pointer transition-all duration-500 group ${
                  isGlow
                    ? 'bg-gradient-to-b from-[#140608] to-[#0a0507] border-2 border-cyber-red shadow-[0_0_40px_rgba(255,18,29,0.25)] hover:shadow-[0_0_60px_rgba(255,18,29,0.55)] hover:border-[#ff222d]'
                    : 'bg-gradient-to-b from-[#0b0b0e]/95 to-[#060608]/95 border border-white/5 hover:border-cyber-red/40 hover:shadow-[0_10px_25px_rgba(255,18,29,0.12)]'
                }`}
              >
                {/* 1. Hanging orb/circle overlapping border */}
                <div className={`absolute -top-7 left-1/2 -translate-x-1/2 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isGlow
                    ? 'bg-[#140608] border-2 border-cyber-red shadow-[0_0_20px_rgba(255,18,29,0.4)]'
                    : 'bg-[#0b0b0e] border border-white/10 group-hover:border-cyber-red/50 hover:shadow-[0_0_15px_rgba(255,18,29,0.2)]'
                }`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-black/50 border border-white/5`}>
                    {plan.icon}
                  </div>
                </div>

                {/* 2. Overlap selection pointer node */}
                {isGlow && (
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 rotate-45 bg-[#140608] border-l-2 border-t-2 border-cyber-red" />
                )}

                {/* Card header contents */}
                <div className="text-center flex flex-col items-center">
                  
                  {/* Pill badge descriptor */}
                  <div className="mb-4">
                    <span className={`inline-block px-3.5 py-1 rounded-full font-mono text-[9px] font-black tracking-[0.2em] uppercase transition-all duration-300 ${
                      isGlow
                        ? 'bg-cyber-red/10 border border-cyber-red text-cyber-red text-glow-red'
                        : 'bg-white/5 border border-white/10 text-zinc-400 group-hover:text-zinc-200'
                    }`}>
                      {plan.badge}
                    </span>
                  </div>

                  {/* Large display italicized price block */}
                  <div className="my-2 flex flex-col items-center">
                    <span className="text-4xl sm:text-5xl font-display font-black text-white tracking-tight italic">
                      {plan.price}
                    </span>
                    <span className="font-mono text-[9px] text-zinc-500 font-bold tracking-widest uppercase mt-1">
                      / {plan.duration}
                    </span>
                  </div>

                  {/* Sub description */}
                  <p className="text-xs text-zinc-400 mt-2 min-h-[1.25rem] font-sans font-light">
                    {plan.desc}
                  </p>

                  <div className="w-16 h-[2px] bg-white/5 my-6 group-hover:w-24 group-hover:bg-cyber-red/40 transition-all duration-500" />

                  {/* Feature lists */}
                  <ul className="space-y-3.5 w-full text-left">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex gap-2.5 text-xs text-zinc-300 font-sans items-center">
                        <span className={`flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center bg-cyber-dark border ${
                          isGlow ? 'border-cyber-red/40 text-cyber-red' : 'border-neutral-800 text-zinc-500'
                        }`}>
                          <Check className="w-2.5 h-2.5" />
                        </span>
                        <span className="font-light tracking-wide">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Glowing capsule start/action CTA button */}
                <div className="mt-8">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => onPlanSelect(plan.name)}
                    className={`w-full py-3 rounded-full font-display text-[10px] sm:text-[11px] font-black uppercase tracking-widest cursor-pointer transition-all duration-300 relative overflow-hidden flex items-center justify-center gap-1.5 border ${
                      isGlow
                        ? 'bg-cyber-red border-cyber-red text-white shadow-[0_0_20px_rgba(255,18,29,0.4)] hover:shadow-[0_0_30px_rgba(255,18,29,0.7)] hover:bg-[#ff202a]'
                        : 'bg-[#101014] border-white/5 hover:border-cyber-red/40 text-zinc-300 group-hover:text-white'
                    }`}
                  >
                    <span className="relative z-10 text-glow-red">Join Now</span>
                    <span className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/5 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  </motion.button>
                  {isGlow && (
                    <span className="block text-[8px] font-mono tracking-widest text-cyber-red uppercase font-black text-center mt-2.5 animate-pulse">
                      * Limited time offer *
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* EID SPECIAL OFFER SECTION (SEPARATE HIGHLIGHT CARD WITH STRONG URGENCY) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto rounded-3xl p-6 sm:p-10 bg-gradient-to-r from-[#170506]/95 via-cyber-dark/95 to-[#120a0b]/90 border-2 border-cyber-red/40 relative overflow-hidden shadow-[0_15px_50px_rgba(255,18,29,0.18)]"
        >
          {/* Neon lights decorative */}
          <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-cyber-red/10 blur-[90px] pointer-events-none" />
          <div className="absolute top-0 left-0 w-[500px] h-[2px] bg-gradient-to-r from-transparent via-cyber-red/60 to-transparent" />

          {/* Top urgency labels info */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 mb-8 pb-6 border-b border-white/5">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-md bg-cyber-red/20 border border-cyber-red/40 font-mono text-[9px] tracking-widest text-cyber-red uppercase font-black animate-pulse">
                  SPECIAL INVITATION
                </span>
                <span className="flex items-center gap-1 font-mono text-xs text-amber-500 font-semibold uppercase">
                  <AlertCircle className="w-3.5 h-3.5" /> ONLY {seatsLeft} SEATS LEFT!
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-display font-black text-white tracking-tight uppercase">
                Limited Eid Special Offer <span className="text-[#a6abba] font-light text-xl sm:text-2xl lowercase italic">(only 20 seats)</span>
              </h3>
            </div>

            {/* Simulated Live Countdown Widget */}
            <div className="flex items-center gap-2 bg-[#050505]/85 border border-cyber-red/30 px-4 py-2.5 rounded-2xl">
              <Clock className="w-4 h-4 text-cyber-red animate-spin-slow shrink-0" />
              <div className="font-mono text-xs tracking-wider text-gray-400 flex items-center gap-1">
                <span className="text-white font-extrabold">{timeLeft.hours.toString().padStart(2, '0')}</span>h
                <span className="text-white font-extrabold">{timeLeft.minutes.toString().padStart(2, '0')}</span>m
                <span className="text-white font-extrabold">{timeLeft.seconds.toString().padStart(2, '0')}</span>s
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Offer choice list */}
            <div className="space-y-4">
              <p className="text-zinc-400 font-sans text-xs leading-relaxed max-w-md">
                Claim your long-term athletic pass card below at unprecedented rates built exclusively to cement life-long commitment. Full facilities, climate biosphere, steam bath, and lockers included.
              </p>

              <div className="space-y-3 pt-2">
                <div 
                  onClick={() => setSelectedOfferOption('10months')}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all duration-300 cursor-pointer ${
                    selectedOfferOption === '10months'
                      ? 'bg-cyber-red/10 border-cyber-red/60 shadow-[0_0_12px_rgba(255,18,29,0.15)] text-white'
                      : 'bg-black/40 border-white/5 hover:border-white/15 text-zinc-400'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedOfferOption === '10months' ? 'border-cyber-red' : 'border-neutral-700'}`}>
                      {selectedOfferOption === '10months' && <span className="w-2 h-2 rounded-full bg-cyber-red" />}
                    </span>
                    <span className="font-display font-black tracking-wide text-sm uppercase">10 Months Access Pack</span>
                  </div>
                  <span className="font-mono font-extrabold text-cyber-red text-base">৳2,000</span>
                </div>

                <div 
                  onClick={() => setSelectedOfferOption('16months')}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all duration-300 cursor-pointer ${
                    selectedOfferOption === '16months'
                      ? 'bg-cyber-red/10 border-cyber-red/60 shadow-[0_0_12px_rgba(255,18,29,0.15)] text-white'
                      : 'bg-black/40 border-white/5 hover:border-white/15 text-zinc-400'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedOfferOption === '16months' ? 'border-cyber-red' : 'border-neutral-700'}`}>
                      {selectedOfferOption === '16months' && <span className="w-2 h-2 rounded-full bg-cyber-red" />}
                    </span>
                    <span className="font-display font-black tracking-wide text-sm uppercase">16 Months Ultimate VIP Pack</span>
                  </div>
                  <span className="font-mono font-extrabold text-cyber-red text-base">৳2,500</span>
                </div>
              </div>
            </div>

            {/* Absolute visual preview with claim button */}
            <div className="p-6 rounded-2xl bg-black/60 border border-white/5 flex flex-col justify-between items-stretch text-center relative h-full">
              <div className="absolute -top-3 right-4 px-3 py-1 bg-amber-500 rounded-md font-mono text-[9px] text-black font-black tracking-widest uppercase">
                CRITICAL LIMIT
              </div>

              <div>
                <span className="font-mono text-[10px] tracking-widest text-[#888] uppercase block mb-1">
                  ACTIVE SELECTION DETECTOR
                </span>
                <span className="font-display text-2xl font-black text-white italic uppercase block mb-2 leading-none border-b border-white/10 pb-3">
                  {selectedOfferOption === '10months' ? 'Eid Special 10 Months' : 'Eid Special 16 Months'}
                </span>

                <div className="py-2">
                  <span className="text-[11px] font-mono text-zinc-400 tracking-wider block">
                    All admission fees waived completely. Priority lock assigned instantly at reception.
                  </span>
                </div>
              </div>

              <div className="mt-6">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => onPlanSelect(selectedOfferOption === '10months' ? 'Eid Special 10 Months' : 'Eid Special 16 Months')}
                  className="w-full py-4 rounded-full bg-gradient-to-r from-amber-500 via-cyber-red to-red-600 text-white font-display text-[12px] font-black uppercase tracking-widest cursor-pointer shadow-[0_0_25px_rgba(255,18,29,0.4)] hover:shadow-[0_0_40px_rgba(255,18,29,0.8)] border border-cyber-red duration-300 transition-all text-glow-red"
                >
                  Claim Offer
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}

import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X, User, MapPin, Smartphone, MessageCircle } from 'lucide-react';
import { PlanName } from '../types';

interface JoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: PlanName;
}

export default function JoinModal({ isOpen, onClose, selectedPlan }: JoinModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [currentPlan, setCurrentPlan] = useState<PlanName>(selectedPlan);

  // Sync state if selectedPlan changes when modal is reopened
  React.useEffect(() => {
    if (isOpen) {
      setCurrentPlan(selectedPlan);
    }
  }, [isOpen, selectedPlan]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !phone) {
      alert('Please fill out your Name and Phone Number to continue.');
      return;
    }

    const gymWhatsAppNumber = '8801904485009'; // POWERSURGE Gym Dhaka Phone Number

    // Dynamic details lookups based on selected plan
    const planDetails: Record<string, { name: string; duration: string; price: string; benefits: string }> = {
      'General': {
        name: 'General Consultation / Custom Plan',
        duration: 'Flexible',
        price: 'Custom Inquiry',
        benefits: '• Full gym access and functional fitness facility\n• Guided fitness evaluation\n• Dynamic environment setup'
      },
      'Admission + 2 Months': {
        name: 'Admission + 2 Months (CORE)',
        duration: '2 Months',
        price: '৳1,500',
        benefits: '• Full gym access\n• Cardio + strength zones\n• Steam bath access\n• Basic trainer support'
      },
      'Admission + 4 Months': {
        name: 'Admission + 4 Months (OVERDRIVE)',
        duration: '4 Months',
        price: '৳2,000',
        benefits: '• Full gym access\n• Cardio + strength zones\n• Steam bath access\n• Priority trainer guidance\n• Locker access'
      },
      'Admission + 6 Months': {
        name: 'Admission + 6 Months (TITAN)',
        duration: '6 Months',
        price: '৳2,500',
        benefits: '• Full gym access\n• Cardio + strength zones\n• Steam bath access\n• Advanced trainer support\n• Supplement guidance support'
      },
      'Admission + 12 Months': {
        name: 'Admission + 12 Months (PREMIUM)',
        duration: '12 Months',
        price: '৳3,000',
        benefits: '• Full gym access\n• All facilities included\n• Steam bath + locker\n• Full trainer support\n• Priority assistance'
      },
      'Eid Special 10 Months': {
        name: 'Eid Special 10 Months Access Pack',
        duration: '10 Months',
        price: '৳2,000',
        benefits: '• Full gym access\n• All facilities, steam bath & lockers\n• Admission fee waived completely\n• Priority lock assigned instantly at reception'
      },
      'Eid Special 16 Months': {
        name: 'Eid Special 16 Months Ultimate VIP Pack',
        duration: '16 Months',
        price: '৳2,500',
        benefits: '• Full gym access\n• All facilities, steam bath & lockers\n• Admission fee waived completely\n• Priority lock assigned instantly at reception'
      }
    };

    const targetDetails = planDetails[currentPlan] || planDetails['General'];

    // Precompiled highly stylized and structured message template as requested
    const message = `Hello POWERSURGE Team,

I want to join the following plan:

Plan: ${targetDetails.name}
Duration: ${targetDetails.duration}
Price: ${targetDetails.price}

Plan Benefits:
${targetDetails.benefits}

Applicant Information:
Name: ${name}
Phone: ${phone}
Address: ${address ? address : 'Not provided'}

I am ready to start my fitness journey. Please guide me.

Thank you.`;

    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${gymWhatsAppNumber}?text=${encodedText}`;

    // Open WhatsApp
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
          {/* Backdrop mask */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/85 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl glass-modal p-6 sm:p-8 md:p-10 text-white z-10 border border-cyber-red/30 shadow-[0_0_40px_rgba(255,18,29,0.15)] scrollbar-thin"
          >
            {/* Top red glow accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-[2px] bg-gradient-to-r from-transparent via-cyber-red to-transparent shadow-[0_0_15px_#ff121d]" />

            {/* Header */}
            <div className="flex justify-between items-center mb-6">
              <div>
                <span className="font-mono text-[10px] sm:text-xs tracking-[0.25em] text-cyber-red uppercase font-bold block">
                  Secure Access Protocol
                </span>
                <h3 className="text-2xl sm:text-3xl font-display font-black tracking-tight mt-1 uppercase italic">
                  JOIN THE <span className="text-cyber-red text-glow-red">SURGE</span>
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-white/5 text-gray-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Close Modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Selected Plan badge/selector */}
              <div className="p-4 rounded-2xl bg-[#070709]/90 border border-white/5 flex flex-col gap-2">
                <label className="font-mono text-[9px] sm:text-[10px] tracking-wider text-gray-400 uppercase font-semibold">
                  Selected Power Level
                </label>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <span className="font-display text-base sm:text-lg font-bold text-cyber-red">
                    {currentPlan === 'General' ? 'Choose a Membership Plan' : currentPlan}
                  </span>
                  <select
                    value={currentPlan}
                    onChange={(e) => setCurrentPlan(e.target.value as PlanName)}
                    className="bg-cyber-dark text-xs border border-white/10 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-cyber-red transition-all cursor-pointer font-sans"
                  >
                    <option value="General">General / Custom</option>
                    <option value="Admission + 2 Months">Admission + 2 Months (৳1,500)</option>
                    <option value="Admission + 4 Months">Admission + 4 Months (৳2,000)</option>
                    <option value="Admission + 6 Months">Admission + 6 Months (৳2,500)</option>
                    <option value="Admission + 12 Months">Admission + 12 Months (৳3,000)</option>
                    <option value="Eid Special 10 Months">Eid Special 10 Months (৳2,000)</option>
                    <option value="Eid Special 16 Months">Eid Special 16 Months (৳2,500)</option>
                  </select>
                </div>
              </div>

              {/* Full Name Input */}
              <div className="space-y-2">
                <label className="font-mono text-xs tracking-wider text-gray-300 uppercase block font-semibold">
                  Full Name <span className="text-cyber-red">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Tanvir Rahman"
                    className="w-full bg-cyber-dark/40 border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyber-red focus:ring-1 focus:ring-cyber-red transition-all"
                  />
                </div>
              </div>

              {/* Phone Input */}
              <div className="space-y-2">
                <label className="font-mono text-xs tracking-wider text-gray-300 uppercase block font-semibold">
                  WhatsApp Phone <span className="text-cyber-red">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                    <Smartphone className="w-4 h-4" />
                  </span>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 01904-485009"
                    className="w-full bg-cyber-dark/40 border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyber-red focus:ring-1 focus:ring-cyber-red transition-all"
                  />
                </div>
              </div>

              {/* Address Input */}
              <div className="space-y-2">
                <label className="font-mono text-xs tracking-wider text-gray-300 uppercase block font-semibold">
                  Local Address
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                    <MapPin className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. Mirpur-2, Dhaka"
                    className="w-full bg-cyber-dark/40 border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyber-red focus:ring-1 focus:ring-cyber-red transition-all"
                  />
                </div>
              </div>

              {/* Submit CTA */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full mt-4 bg-gradient-to-r from-cyber-red to-[#d00510] hover:shadow-[0_0_25px_rgba(255,18,29,0.5)] text-white font-display font-black uppercase tracking-widest text-xs py-4 rounded-xl flex items-center justify-center gap-2.5 transition-all duration-300 cursor-pointer text-glow-red"
              >
                <MessageCircle className="w-4 h-4 text-white animate-pulse" />
                <span>Activate Membership Access</span>
              </motion.button>

              <p className="text-[10px] text-zinc-500 text-center font-mono leading-relaxed uppercase">
                transmitting this form initiates an express communication link directly with our front desk managers.
              </p>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

import { motion } from 'motion/react';
import { Instagram, Twitter, Facebook } from 'lucide-react';
import { Trainer } from '../types';

export default function Trainers() {
  const trainersList = [
    {
      id: 'trainer-1',
      name: 'A AL Sami Rishad',
      specialty: 'Senior Fitness Trainer',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/514407789_24150816817884618_5041643309264312375_n_tcpzgq',
      description: 'Expert in progressive overload resistance structures, body recomposition, and professional competition meal planning.',
      socials: {},
    },
    {
      id: 'trainer-2',
      name: 'Saief Hassan Dhrubo',
      specialty: 'Gym Trainer',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/703587643_1337966801618962_7804602433552604370_n_fjcbpj',
      description: 'Specialist in metabolic cardiovascular condition routines, high-intensity kettlebells, and safe posture mechanics.',
      socials: {},
    },
    {
      id: 'trainer-3',
      name: 'Swapnil',
      specialty: 'Strength & Conditioning Coach',
      image: 'https://res.cloudinary.com/dahuljalj/image/upload/f_auto/482012074_9475167682546721_8680380375061203290_n_e0a11n',
      description: 'Biomechanical force developer, powerlifting athletic transition guide, and injury preventive rehabilitation.',
      socials: {},
    },
  ];

  return (
    <section id="trainers" className="py-24 bg-cyber-dark relative overflow-hidden select-none">
      {/* Absolute decorative red neon glowing element */}
      <div className="absolute top-1/4 left-10 w-[300px] h-[300px] rounded-full bg-cyber-red/5 blur-[90px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <span className="font-mono text-xs tracking-[0.3em] font-semibold text-cyber-red uppercase block">
            CHAMPIONSHIP BODY DESIGNERS
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-black tracking-tighter text-white uppercase italic">
            ELITE <span className="text-cyber-red text-glow-red">TRAINING CREW</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto font-light font-sans">
            Train with Bangladesh National players, professional body designers, and highly supportive, welcoming physical mentors.
          </p>
        </div>

        {/* Trainers cards list */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto mb-16">
          {trainersList.map((trainer, index) => (
            <motion.div
              key={trainer.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              whileHover={{ y: -6 }}
              className="relative group rounded-2xl overflow-hidden glass-card border border-white/5 flex flex-col shadow-[0_4px_30px_rgba(0,0,0,0.3)] neon-hover-card cursor-pointer"
            >
              {/* Image Frame with crop aspect 3:4 */}
              <div className="relative aspect-[3/4] overflow-hidden bg-cyber-dark">
                <img
                  src={trainer.image}
                  alt={trainer.name}
                  className="w-full h-full object-cover object-center transition-transform duration-[6s] ease-out group-hover:scale-108"
                  referrerPolicy="no-referrer"
                />

                {/* Left/Right fine borders */}
                <div className="absolute inset-0 border border-transparent group-hover:border-cyber-red/20 transition-all duration-500 rounded-t-2xl pointer-events-none" />

                {/* Dark overlay with dynamic transition on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark via-cyber-dark/10 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />
              </div>

              {/* Text Context (below crop frame) */}
              <div className="p-6 relative bg-cyber-dark/95 flex-grow border-t border-white/5 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-display font-extrabold text-white tracking-tight group-hover:text-cyber-red transition-colors">
                    {trainer.name}
                  </h3>
                  <p className="text-xs font-mono tracking-widest text-cyber-red uppercase font-semibold mt-1">
                    {trainer.specialty}
                  </p>
                  
                  {/* Clean physical biometric short description */}
                  <p className="text-xs text-zinc-400 font-sans mt-3.5 leading-relaxed font-light">
                    {trainer.description}
                  </p>
                </div>

                <div className="h-[2px] w-12 bg-cyber-red/30 group-hover:w-full transition-all duration-500 mt-5 origin-left" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Private Female Training & Supportive Environment Card Callout */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-red-950/20 via-cyber-dark/90 to-[#0e0e11]/80 border border-cyber-red/30 flex flex-col sm:flex-row items-center gap-6 justify-between shadow-[0_8px_30px_rgba(255,18,29,0.06)] relative overflow-hidden"
        >
          {/* subtle decorative background radial light */}
          <div className="absolute top-0 right-0 w-44 h-44 rounded-full bg-cyber-red/10 blur-[50px] pointer-events-none" />

          <div className="space-y-2 text-center sm:text-left">
            <span className="px-3 py-1 rounded-full bg-cyber-red/10 border border-cyber-red/30 font-mono text-[9px] tracking-widest text-cyber-red uppercase font-bold">
              FEMALE TRAINING SUPPORT
            </span>
            <h4 className="font-display font-bold text-lg text-white leading-snug">
              LOOKING FOR AN OPTIONAL ASSIGNED FEMALE COACH?
            </h4>
            <p className="text-zinc-400 font-sans text-xs max-w-xl font-light">
              POWERSURGE Gym offers deep physical training environments. Professional private female physical guidance is readily available upon request to make your stamina journey perfectly guided.
            </p>
          </div>

          <a
            href="#pricing"
            className="flex-shrink-0 px-6 py-3 rounded-full bg-[#0a0a0c] border border-cyber-red/50 hover:border-cyber-red hover:bg-cyber-red/15 text-white font-mono text-2xs font-extrabold tracking-widest uppercase transition-all duration-300 cursor-pointer shadow-[0_0_12px_rgba(255,18,29,0.15)] select-none"
          >
            DISCOVER SCHEDULING
          </a>
        </motion.div>

      </div>
    </section>
  );
}

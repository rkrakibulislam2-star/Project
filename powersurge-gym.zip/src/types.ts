export type PlanName = string;

export interface Trainer {
  id: string;
  name: string;
  specialty: string;
  image: string;
  socials: {
    instagram?: string;
    twitter?: string;
    facebook?: string;
  };
}

export interface Facility {
  id: string;
  title: string;
  desc: string;
  iconName: string;
  imageUrl?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  image: string;
  review: string;
  rating: number;
  beforeAfter?: {
    before: string;
    after: string;
  };
}

export interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  category: string;
}

/**
 * Programmatic ultra-smooth scrolling with custom cubic-bezier (ease-in-out) easing and configurable duration
 * for a luxurious, slow cinematic glide.
 */
export function smoothScrollTo(targetSelector: string, duration: number = 1100) {
  const target = document.querySelector(targetSelector);
  if (!target) return;

  // Add small offset to perfectly balance headers if needed, normally 0 or navbar height
  const navbarElement = document.getElementById('navbar-header');
  const offset = navbarElement ? navbarElement.offsetHeight : 0;

  const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
  const startPosition = window.pageYOffset;
  const distance = targetPosition - startPosition;
  let startTime: number | null = null;

  // Beautiful cinematic cubic easement function (slow start, fast middle, slow end)
  function easeInOutCubic(t: number, b: number, c: number, d: number) {
    t /= d / 2;
    if (t < 1) return (c / 2) * t * t * t + b;
    t -= 2;
    return (c / 2) * (t * t * t + 2) + b;
  }

  function animation(currentTime: number) {
    if (startTime === null) startTime = currentTime;
    const timeElapsed = currentTime - startTime;
    const run = easeInOutCubic(timeElapsed, startPosition, distance, duration);
    
    window.scrollTo(0, run);
    
    if (timeElapsed < duration) {
      requestAnimationFrame(animation);
    } else {
      window.scrollTo(0, targetPosition);
    }
  }

  requestAnimationFrame(animation);
}
